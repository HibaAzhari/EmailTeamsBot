﻿using EmailBot.Common.Models;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Mail;
using System.Text;

namespace EmailBot.Common.Helpers
{
    public class SendMailHelper
    {
        public static void SendMail(UserEntity user)
        {
            var mailMessage = new MailMessage
            {
                From = new MailAddress("hiba@hibaazhari.onmicrosoft.com"),
                Subject = "Registered Email",
                Body = "Hi " + user.Name + " from " + user.Department + ". Thank you for signing up!"
            };

            mailMessage.To.Add(user.AltEmail);

            var smtpClient = new SmtpClient
            {
                Credentials = new NetworkCredential("apikey", "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"),
                Host = "smtp.sendgrid.net",
                Port = 587
            };

            smtpClient.Send(mailMessage);
        }

    }
}
