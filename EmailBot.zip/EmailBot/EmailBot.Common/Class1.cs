﻿using System;

namespace EmailBot.Common
{
    public class Class1
    {
    }
}
